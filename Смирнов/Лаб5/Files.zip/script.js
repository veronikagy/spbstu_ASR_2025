(() => {
  "use strict";

  const header = document.querySelector("[data-header]");
  const burger = document.querySelector("[data-burger]");
  const nav = document.querySelector("[data-nav]");
  const form = document.querySelector("[data-form]");
  const emailInput = document.querySelector("[data-email]");

  if (!burger || !nav) return;

  const DESKTOP_BREAKPOINT = 860;

  const setMenuState = (open) => {
    nav.classList.toggle("is-open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
    document.body.classList.toggle("menu-open", open);
  };

  const isMenuOpen = () => burger.getAttribute("aria-expanded") === "true";

  burger.addEventListener("click", () => {
    setMenuState(!isMenuOpen());
  });

  // Close menu when clicking a nav link (mobile)
  nav.addEventListener("click", (e) => {
    const link = e.target.closest("a[href^='#']");
    if (!link) return;

    // Close only for mobile layout
    if (window.innerWidth < DESKTOP_BREAKPOINT) {
      setMenuState(false);
    }
  });

  // Close menu on Escape
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (isMenuOpen()) setMenuState(false);
  });

  // Close menu if switching to desktop layout
  window.addEventListener("resize", () => {
    if (window.innerWidth >= DESKTOP_BREAKPOINT) {
      setMenuState(false);
    }
  });

  // Improve anchor scrolling with sticky header offset (no experimental APIs)
  document.addEventListener("click", (e) => {
    const link = e.target.closest("a[href^='#']");
    if (!link) return;

    const id = link.getAttribute("href");
    if (!id || id === "#") return;

    const target = document.querySelector(id);
    if (!target) return;

    e.preventDefault();

    const headerHeight = header ? header.getBoundingClientRect().height : 0;
    const top = window.pageYOffset + target.getBoundingClientRect().top - headerHeight - 10;

    window.scrollTo({ top, behavior: "smooth" });
    history.pushState(null, "", id);
  });

  // Form validation (client-side only)
  if (form && emailInput) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    const setInvalid = (invalid) => {
      emailInput.classList.toggle("is-invalid", invalid);
      emailInput.setAttribute("aria-invalid", String(invalid));
    };

    emailInput.addEventListener("input", () => {
      setInvalid(false);
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const value = String(emailInput.value || "").trim();
      const ok = emailRegex.test(value);

      if (!ok) {
        setInvalid(true);
        emailInput.focus();
        return;
      }

      setInvalid(false);
      alert("Спасибо! Мы свяжемся с вами.");
      emailInput.value = "";
      emailInput.blur();
    });
  }
})();